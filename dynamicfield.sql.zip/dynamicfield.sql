-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 19, 2016 at 06:07 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dynamicfield`
--

-- --------------------------------------------------------

--
-- Table structure for table `my_hobbies`
--

CREATE TABLE `my_hobbies` (
  `id` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `unique` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `my_hobbies`
--

INSERT INTO `my_hobbies` (`id`, `email`, `unique`) VALUES
(36, 'thy@hmns.com', '56ebc216b14d1'),
(37, 'saa@gmail.com', '56ebc32419522'),
(38, 'sddsdds@gmail.cm', '56ebc324275aa'),
(39, 'www@gmail.com', '56ebc3243218e'),
(40, 'qqqwq@gmail.com', '56ebc3244ff1d'),
(41, 'op@gmail.com', '56ebc32465a20'),
(42, 'srinivas@gmail.com', '56ebc88555e62'),
(43, 'srinivas@gmail.com', '56ebcfe3649da'),
(44, 'teja@gmail.com', '56ebcff9cbf27'),
(45, 'dsdd@gmail.com', '56ebcff9ce48a'),
(46, 'teja@gmail.com', '56ebd1488fd3e'),
(47, 'dsdd@gmail.com', '56ebd14892ccf'),
(48, 'dssdsdsd@gmail.com', '56ecde177e152'),
(49, 'dssdsdsd@gmail.com', '56ecde36a27de'),
(50, 'srinivas@gmail.com', '56ecde3f8dbe5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `my_hobbies`
--
ALTER TABLE `my_hobbies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `my_hobbies`
--
ALTER TABLE `my_hobbies`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
